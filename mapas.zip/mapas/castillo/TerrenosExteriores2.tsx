<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TerrenosExteriores2" tilewidth="32" tileheight="32" tilecount="624" columns="26">
 <image source="TerrenosExteriores2.png" width="840" height="786"/>
</tileset>
