<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TerrenosExterirores" tilewidth="32" tileheight="32" tilecount="483" columns="21">
 <image source="TerrenosExteriores.png" width="672" height="736"/>
 <tile id="383">
  <properties>
   <property name="colider" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
