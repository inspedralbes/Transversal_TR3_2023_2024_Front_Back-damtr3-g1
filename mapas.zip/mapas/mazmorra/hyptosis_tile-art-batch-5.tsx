<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="hyptosis_tile-art-batch-5" tilewidth="32" tileheight="32" tilecount="722" columns="19">
 <image source="hyptosis_tile-art-batch-5.png" width="636" height="1219"/>
</tileset>
